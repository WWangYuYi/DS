package com.example.demo2.bean;

import java.util.List;

public class BrandDetail2 {

    /**
     * errno : 0
     * errmsg :
     * data : {"count":19,"totalPages":1,"pageSize":1000,"currentPage":1,"data":[{"id":1130037,"name":"帆布丝羽绒多用坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png","retail_price":39},{"id":1115028,"name":"日式色织水洗棉条纹四件套","list_pic_url":"http://yanxuan.nosdn.127.net/3d0045e8f43439c7004fae052b2162ed.png","retail_price":299},{"id":1110007,"name":"日式色织水洗棉格纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/deeb55bb45f94cb236a47d1264e883b8.png","retail_price":299},{"id":1110004,"name":"全棉针织纯色四件套","list_pic_url":"http://yanxuan.nosdn.127.net/1ffd5831e63027715445f74a28f8c4ed.png","retail_price":299},{"id":1110003,"name":"全棉针织条纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/72dfb4bfc1cd1b834c064a9d1d40627d.png","retail_price":299},{"id":1109008,"name":"云端沙发组合","list_pic_url":"http://yanxuan.nosdn.127.net/c5be2604c0e4186a4e7079feeb742cee.png","retail_price":3999},{"id":1090004,"name":"日式法兰绒格子四件套","list_pic_url":"http://yanxuan.nosdn.127.net/a3a92057f10e5e6e804c19ef495e3dee.png","retail_price":399},{"id":1075024,"name":"升级款纯棉静音白鹅羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/ce4a1eb18ea518bf584620632509935f.png","retail_price":2399},{"id":1057036,"name":"日式纯色水洗亚麻抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/8a9ee5ba08929cc9e40b973607d2f633.png","retail_price":79},{"id":1055016,"name":"日式纯棉针织条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/23e0203f1512f33e605f61c28fa03d2d.png","retail_price":59},{"id":1048005,"name":"日式色织水洗条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/ce980c16810a471dffff6aa8d7bac754.png","retail_price":59},{"id":1043005,"name":"日式记忆绵坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/2a95b16f5b147cab4845641bee738a2e.png","retail_price":59},{"id":1039051,"name":"多功能午睡枕","list_pic_url":"http://yanxuan.nosdn.127.net/c8ca0600fa7ba11ca8be6a3173dd38c9.png","retail_price":79},{"id":1027004,"name":"色织六层纱布夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/6252f53aaf36c072b6678f3d8c635132.png","retail_price":249},{"id":1023034,"name":"泡泡纱可水洗夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/715899c65c023bb4973fb0466a5b79d6.png","retail_price":299},{"id":1023012,"name":"色织华夫格夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/07376e78bf4fb8a5aa8e6a0b1437c3ad.png","retail_price":299},{"id":1020000,"name":"升级款记忆绵护椎腰靠","list_pic_url":"http://yanxuan.nosdn.127.net/819fdf1f635a694166bcfdd426416e8c.png","retail_price":79},{"id":1011004,"name":"色织精梳AB纱格纹空调被","list_pic_url":"http://yanxuan.nosdn.127.net/0984c9388a2c3fd2335779da904be393.png","retail_price":199},{"id":1009009,"name":"白鹅绒秋冬加厚羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/9791006f25e26b2d7c81f41f87ce8619.png","retail_price":1999}],"filterCategory":[{"id":0,"name":"全部","checked":true},{"id":1005000,"name":"居家","checked":false}],"goodsList":[{"id":1130037,"name":"帆布丝羽绒多用坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png","retail_price":39},{"id":1115028,"name":"日式色织水洗棉条纹四件套","list_pic_url":"http://yanxuan.nosdn.127.net/3d0045e8f43439c7004fae052b2162ed.png","retail_price":299},{"id":1110007,"name":"日式色织水洗棉格纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/deeb55bb45f94cb236a47d1264e883b8.png","retail_price":299},{"id":1110004,"name":"全棉针织纯色四件套","list_pic_url":"http://yanxuan.nosdn.127.net/1ffd5831e63027715445f74a28f8c4ed.png","retail_price":299},{"id":1110003,"name":"全棉针织条纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/72dfb4bfc1cd1b834c064a9d1d40627d.png","retail_price":299},{"id":1109008,"name":"云端沙发组合","list_pic_url":"http://yanxuan.nosdn.127.net/c5be2604c0e4186a4e7079feeb742cee.png","retail_price":3999},{"id":1090004,"name":"日式法兰绒格子四件套","list_pic_url":"http://yanxuan.nosdn.127.net/a3a92057f10e5e6e804c19ef495e3dee.png","retail_price":399},{"id":1075024,"name":"升级款纯棉静音白鹅羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/ce4a1eb18ea518bf584620632509935f.png","retail_price":2399},{"id":1057036,"name":"日式纯色水洗亚麻抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/8a9ee5ba08929cc9e40b973607d2f633.png","retail_price":79},{"id":1055016,"name":"日式纯棉针织条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/23e0203f1512f33e605f61c28fa03d2d.png","retail_price":59},{"id":1048005,"name":"日式色织水洗条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/ce980c16810a471dffff6aa8d7bac754.png","retail_price":59},{"id":1043005,"name":"日式记忆绵坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/2a95b16f5b147cab4845641bee738a2e.png","retail_price":59},{"id":1039051,"name":"多功能午睡枕","list_pic_url":"http://yanxuan.nosdn.127.net/c8ca0600fa7ba11ca8be6a3173dd38c9.png","retail_price":79},{"id":1027004,"name":"色织六层纱布夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/6252f53aaf36c072b6678f3d8c635132.png","retail_price":249},{"id":1023034,"name":"泡泡纱可水洗夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/715899c65c023bb4973fb0466a5b79d6.png","retail_price":299},{"id":1023012,"name":"色织华夫格夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/07376e78bf4fb8a5aa8e6a0b1437c3ad.png","retail_price":299},{"id":1020000,"name":"升级款记忆绵护椎腰靠","list_pic_url":"http://yanxuan.nosdn.127.net/819fdf1f635a694166bcfdd426416e8c.png","retail_price":79},{"id":1011004,"name":"色织精梳AB纱格纹空调被","list_pic_url":"http://yanxuan.nosdn.127.net/0984c9388a2c3fd2335779da904be393.png","retail_price":199},{"id":1009009,"name":"白鹅绒秋冬加厚羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/9791006f25e26b2d7c81f41f87ce8619.png","retail_price":1999}]}
     */

    private int errno;
    private String errmsg;
    private DataBeanX data;

    public int getErrno() {
        return errno;
    }

    public void setErrno(int errno) {
        this.errno = errno;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public DataBeanX getData() {
        return data;
    }

    public void setData(DataBeanX data) {
        this.data = data;
    }

    public static class DataBeanX {
        /**
         * count : 19
         * totalPages : 1
         * pageSize : 1000
         * currentPage : 1
         * data : [{"id":1130037,"name":"帆布丝羽绒多用坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png","retail_price":39},{"id":1115028,"name":"日式色织水洗棉条纹四件套","list_pic_url":"http://yanxuan.nosdn.127.net/3d0045e8f43439c7004fae052b2162ed.png","retail_price":299},{"id":1110007,"name":"日式色织水洗棉格纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/deeb55bb45f94cb236a47d1264e883b8.png","retail_price":299},{"id":1110004,"name":"全棉针织纯色四件套","list_pic_url":"http://yanxuan.nosdn.127.net/1ffd5831e63027715445f74a28f8c4ed.png","retail_price":299},{"id":1110003,"name":"全棉针织条纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/72dfb4bfc1cd1b834c064a9d1d40627d.png","retail_price":299},{"id":1109008,"name":"云端沙发组合","list_pic_url":"http://yanxuan.nosdn.127.net/c5be2604c0e4186a4e7079feeb742cee.png","retail_price":3999},{"id":1090004,"name":"日式法兰绒格子四件套","list_pic_url":"http://yanxuan.nosdn.127.net/a3a92057f10e5e6e804c19ef495e3dee.png","retail_price":399},{"id":1075024,"name":"升级款纯棉静音白鹅羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/ce4a1eb18ea518bf584620632509935f.png","retail_price":2399},{"id":1057036,"name":"日式纯色水洗亚麻抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/8a9ee5ba08929cc9e40b973607d2f633.png","retail_price":79},{"id":1055016,"name":"日式纯棉针织条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/23e0203f1512f33e605f61c28fa03d2d.png","retail_price":59},{"id":1048005,"name":"日式色织水洗条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/ce980c16810a471dffff6aa8d7bac754.png","retail_price":59},{"id":1043005,"name":"日式记忆绵坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/2a95b16f5b147cab4845641bee738a2e.png","retail_price":59},{"id":1039051,"name":"多功能午睡枕","list_pic_url":"http://yanxuan.nosdn.127.net/c8ca0600fa7ba11ca8be6a3173dd38c9.png","retail_price":79},{"id":1027004,"name":"色织六层纱布夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/6252f53aaf36c072b6678f3d8c635132.png","retail_price":249},{"id":1023034,"name":"泡泡纱可水洗夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/715899c65c023bb4973fb0466a5b79d6.png","retail_price":299},{"id":1023012,"name":"色织华夫格夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/07376e78bf4fb8a5aa8e6a0b1437c3ad.png","retail_price":299},{"id":1020000,"name":"升级款记忆绵护椎腰靠","list_pic_url":"http://yanxuan.nosdn.127.net/819fdf1f635a694166bcfdd426416e8c.png","retail_price":79},{"id":1011004,"name":"色织精梳AB纱格纹空调被","list_pic_url":"http://yanxuan.nosdn.127.net/0984c9388a2c3fd2335779da904be393.png","retail_price":199},{"id":1009009,"name":"白鹅绒秋冬加厚羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/9791006f25e26b2d7c81f41f87ce8619.png","retail_price":1999}]
         * filterCategory : [{"id":0,"name":"全部","checked":true},{"id":1005000,"name":"居家","checked":false}]
         * goodsList : [{"id":1130037,"name":"帆布丝羽绒多用坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png","retail_price":39},{"id":1115028,"name":"日式色织水洗棉条纹四件套","list_pic_url":"http://yanxuan.nosdn.127.net/3d0045e8f43439c7004fae052b2162ed.png","retail_price":299},{"id":1110007,"name":"日式色织水洗棉格纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/deeb55bb45f94cb236a47d1264e883b8.png","retail_price":299},{"id":1110004,"name":"全棉针织纯色四件套","list_pic_url":"http://yanxuan.nosdn.127.net/1ffd5831e63027715445f74a28f8c4ed.png","retail_price":299},{"id":1110003,"name":"全棉针织条纹四件套 新款","list_pic_url":"http://yanxuan.nosdn.127.net/72dfb4bfc1cd1b834c064a9d1d40627d.png","retail_price":299},{"id":1109008,"name":"云端沙发组合","list_pic_url":"http://yanxuan.nosdn.127.net/c5be2604c0e4186a4e7079feeb742cee.png","retail_price":3999},{"id":1090004,"name":"日式法兰绒格子四件套","list_pic_url":"http://yanxuan.nosdn.127.net/a3a92057f10e5e6e804c19ef495e3dee.png","retail_price":399},{"id":1075024,"name":"升级款纯棉静音白鹅羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/ce4a1eb18ea518bf584620632509935f.png","retail_price":2399},{"id":1057036,"name":"日式纯色水洗亚麻抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/8a9ee5ba08929cc9e40b973607d2f633.png","retail_price":79},{"id":1055016,"name":"日式纯棉针织条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/23e0203f1512f33e605f61c28fa03d2d.png","retail_price":59},{"id":1048005,"name":"日式色织水洗条纹抱枕","list_pic_url":"http://yanxuan.nosdn.127.net/ce980c16810a471dffff6aa8d7bac754.png","retail_price":59},{"id":1043005,"name":"日式记忆绵坐垫","list_pic_url":"http://yanxuan.nosdn.127.net/2a95b16f5b147cab4845641bee738a2e.png","retail_price":59},{"id":1039051,"name":"多功能午睡枕","list_pic_url":"http://yanxuan.nosdn.127.net/c8ca0600fa7ba11ca8be6a3173dd38c9.png","retail_price":79},{"id":1027004,"name":"色织六层纱布夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/6252f53aaf36c072b6678f3d8c635132.png","retail_price":249},{"id":1023034,"name":"泡泡纱可水洗夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/715899c65c023bb4973fb0466a5b79d6.png","retail_price":299},{"id":1023012,"name":"色织华夫格夏凉被","list_pic_url":"http://yanxuan.nosdn.127.net/07376e78bf4fb8a5aa8e6a0b1437c3ad.png","retail_price":299},{"id":1020000,"name":"升级款记忆绵护椎腰靠","list_pic_url":"http://yanxuan.nosdn.127.net/819fdf1f635a694166bcfdd426416e8c.png","retail_price":79},{"id":1011004,"name":"色织精梳AB纱格纹空调被","list_pic_url":"http://yanxuan.nosdn.127.net/0984c9388a2c3fd2335779da904be393.png","retail_price":199},{"id":1009009,"name":"白鹅绒秋冬加厚羽绒被","list_pic_url":"http://yanxuan.nosdn.127.net/9791006f25e26b2d7c81f41f87ce8619.png","retail_price":1999}]
         */

        private int count;
        private int totalPages;
        private int pageSize;
        private int currentPage;
        private List<DataBean> data;
        private List<FilterCategoryBean> filterCategory;
        private List<GoodsListBean> goodsList;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getCurrentPage() {
            return currentPage;
        }

        public void setCurrentPage(int currentPage) {
            this.currentPage = currentPage;
        }

        public List<DataBean> getData() {
            return data;
        }

        public void setData(List<DataBean> data) {
            this.data = data;
        }

        public List<FilterCategoryBean> getFilterCategory() {
            return filterCategory;
        }

        public void setFilterCategory(List<FilterCategoryBean> filterCategory) {
            this.filterCategory = filterCategory;
        }

        public List<GoodsListBean> getGoodsList() {
            return goodsList;
        }

        public void setGoodsList(List<GoodsListBean> goodsList) {
            this.goodsList = goodsList;
        }

        public static class DataBean {
            /**
             * id : 1130037
             * name : 帆布丝羽绒多用坐垫
             * list_pic_url : http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png
             * retail_price : 39
             */

            private int id;
            private String name;
            private String list_pic_url;
            private String retail_price;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getList_pic_url() {
                return list_pic_url;
            }

            public void setList_pic_url(String list_pic_url) {
                this.list_pic_url = list_pic_url;
            }

            public String getRetail_price() {
                return retail_price;
            }

            public void setRetail_price(String retail_price) {
                this.retail_price = retail_price;
            }
        }

        public static class FilterCategoryBean {
            /**
             * id : 0
             * name : 全部
             * checked : true
             */

            private int id;
            private String name;
            private boolean checked;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public boolean isChecked() {
                return checked;
            }

            public void setChecked(boolean checked) {
                this.checked = checked;
            }
        }

        public static class GoodsListBean {
            /**
             * id : 1130037
             * name : 帆布丝羽绒多用坐垫
             * list_pic_url : http://yanxuan.nosdn.127.net/19ecd7c6f6f31219cf75117238d95139.png
             * retail_price : 39
             */

            private int id;
            private String name;
            private String list_pic_url;
            private int retail_price;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getList_pic_url() {
                return list_pic_url;
            }

            public void setList_pic_url(String list_pic_url) {
                this.list_pic_url = list_pic_url;
            }

            public int getRetail_price() {
                return retail_price;
            }

            public void setRetail_price(int retail_price) {
                this.retail_price = retail_price;
            }
        }
    }
}
