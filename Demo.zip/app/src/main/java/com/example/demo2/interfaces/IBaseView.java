package com.example.demo2.interfaces;

public interface IBaseView {

    void showLoading(int visible);

    void showToast(String tips);

}
